package com.github.jbb248.demo;

import java.awt.Point;
import java.awt.geom.Point2D;

import com.github.jbb248.jburst.JBurstSprite;

public class CollisionSprite extends JBurstSprite
{
    public double step = 1;

    private final Point vector = new Point(1, 1);
    private final Point2D.Double positionD = new Point2D.Double();

    public CollisionSprite()
    {
        this(0, 0);
    }
    
    public CollisionSprite(int x, int y)
    {
        super(x, y);

        positionD.setLocation(x, y);
    }

    @Override
    public void update(double elapsed)
    {
        super.update(elapsed);

        if(vector == null || positionD == null) return;

        positionD.x += 0.1 / elapsed / step * vector.x;
        positionD.y += 0.1 / elapsed / step * vector.y;

        if(positionD.x < 0)
        {
            positionD.setLocation(0, positionD.y);
            vector.x *= -1;
        }
        else if(positionD.x + getSpriteWidth() >= Main.window.getWidth())
        {
            positionD.setLocation(Main.window.getWidth() - getSpriteWidth() - 1, positionD.y);
            vector.x *= -1;
        }
        if(positionD.y < 0)
        {
            positionD.setLocation(positionD.x, 0);
            vector.y *= -1;
        }
        else if(positionD.y + getSpriteHeight() >= Main.window.getHeight())
        {
            positionD.setLocation(positionD.x, Main.window.getHeight() - getSpriteHeight() - 1);
            vector.y *= -1;
        }

        setSpriteLocation((int) positionD.x, (int) positionD.y);
    }
}
