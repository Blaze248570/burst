package com.github.jbb248.demo;

import java.util.stream.IntStream;

public class Pichu extends CollisionSprite
{
    public final String file_location = "graphics/pichu_sheet.png";

    public final int[] indices = IntStream.rangeClosed(0, 43).toArray();

    public Pichu()
    {
        super();

        loadAnimatedGraphic(file_location, 175, 175);
        
        animation.add("Dance", indices);
        animation.play("Dance");
    }
}
