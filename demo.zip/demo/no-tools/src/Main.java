import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class Main 
{
    public final static Dimension resolution = Toolkit.getDefaultToolkit().getScreenSize();

    public static void main(String args[]) 
    {
        SwingUtilities.invokeLater(Main::create);
    }

    public static JFrame window;
    public static Pichu pichu;

    public static final String AUDIO_FILE = "audio/lunchBox.wav";

    public static void create()
    {
        window = new JFrame("Screen Pet");
        window.setSize(resolution.width, resolution.height);
        window.setUndecorated(true);
        window.setBackground(new Color(0, true));
        window.setFocusableWindowState(false);
        window.setAlwaysOnTop(true);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        pichu = new Pichu();
        // Music.playMusic(AUDIO_FILE);

        window.add(pichu);
        
        window.setVisible(true);
        pichu.start();
    }
}