import burst.JBurstSprite;
import burst.graphics.frames.JBurstAtlasFrames;

/**
 * An extended class of JBurstSprite used to draw a Vaporeon.
 * <p>
 * This class employs the {@code fromSparrow()} method to parse its spritesheet.
 */
public class VaporeonSprite extends JBurstSprite
{
    public final String file_location = "assets/Vaporeon";

    public boolean spin = false;

    public VaporeonSprite()
    {
        super();

        // Load frames from sparrow texture pack
        setFrames(JBurstAtlasFrames.fromSparrow(file_location + ".png", file_location + ".xml"));

        animation.addByPrefix("dance", "Vaporeon Idle Dance", 24);
        animation.play("dance");
        kill();
    }

    @Override
    public void update(int elapsed)
    {
        super.update(elapsed);

        if(spin)
            setAngle(getAngle() + Math.toRadians(elapsed / 2.0));
        else
            setAngle(0.0);
    }
}
