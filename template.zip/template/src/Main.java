import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.burst.JBurst;
import javax.swing.burst.JBurstSprite;
import javax.swing.burst.graphics.JBurstGraphic;
import javax.swing.burst.graphics.frames.JBurstAtlasFrames;

public class Main 
{
    private static JButton swapBtn, showBoundsBtn;
    private static final int BTNWIDTH = 125, BTNHEIGHT = 30;

    private static JBurstSprite pichu, alolan_raichu, vaporeon;

    public static void main(String[] args) 
    {
        // Create a JBurst object with the dimensions 800x700 (Not in pixels).
        JBurst app = new JBurst(800, 700);

        // Create a JButton used to swap between sprites.
        swapBtn = new JButton("Default");
        swapBtn.setBounds(25, 25, BTNWIDTH, BTNHEIGHT);
        swapBtn.addActionListener(new SwapButtonListener());

        showBoundsBtn = new JButton("Toggle bounds");
        showBoundsBtn.setBounds(swapBtn.getX(), swapBtn.getY() + BTNHEIGHT + 5, BTNWIDTH, BTNHEIGHT);
        showBoundsBtn.addActionListener(new ShowBoundsButtonListener());

        /**
         * The first sprite uses a spritesheet formatted with the same dimensions for each frame,
         * Allowing for it to be cut evenly without complication
        */
        pichu = new JBurstSprite(300, 60);
        pichu.loadAnimatedGraphic(JBurstGraphic.fromFile("assets/pichu_sheet.png", "pichu"), 175, 175);
        
        /**
         * Animations are seperated by indices, starting at zero. 
         * So one animation may be {0, 1, 2, 3} and another may be {10, 11, 12, 13}.
        */
        int[] frames = new int[44];
        for(int i = 0; i < 44; i++) frames[i] = i;
        pichu.animation.add("Dance", frames);
        pichu.animation.play("Dance");
        pichu.animation.callback = (String name, Integer frameNumber, Integer frameIndex) -> { };


        /** 
         * The second sprite also uses a spritesheet, but the frames are not all the same size.
         * A JSON file is included alongside it with the instructions on how to cut it apart.
        */
        alolan_raichu = new JBurstSprite(50, 20);
        alolan_raichu.loadFrames(JBurstAtlasFrames.fromTexturePackerJson("assets/Alolan_Raichu.png", "assets/Alolan_Raichu.json"));

        /**
         * Adding animations is much simpler this way as each one is assigned a label. 
         * Simply name it, provide its label on the instruction file, and you're good to go.
        */
        alolan_raichu.animation.addByPrefix("dance", "Raichu Idle Dance", 24);
        alolan_raichu.animation.play("dance", true, false, 0);
        alolan_raichu.active = false;
        alolan_raichu.visible = false;


        /**
         * The final sprite has the same situation as the second, however it instead uses the sparrow packing method.
         * So, an XML file is provided alongside it instead.
        */
        vaporeon = new JBurstSprite(40, 60);
        vaporeon.loadFrames(JBurstAtlasFrames.fromSparrow("assets/Vaporeon.png", "assets/Vaporeon.xml"));
        vaporeon.animation.addByPrefix("dance", "Vaporeon Idle Dance", 24);
        vaporeon.animation.play("dance");
        vaporeon.active = false;
        vaporeon.visible = false;

        // The objects are then added to the JBurst so that it knows to render them.
        app.defaultCam.add(swapBtn);
        app.defaultCam.add(showBoundsBtn);

        app.defaultCam.add(pichu);
        app.defaultCam.add(alolan_raichu);
        app.defaultCam.add(vaporeon);

        // Makes the window visible (Makes it exist). Very important!
        app.setVisible(true);

        // Dumb, but necessary for now.
        while(true) 
        {
            app.update();
        }
    }

    /**
     * A button listener is a common private class that is used to manage
     * JButtons and tell them what to do when they're pressed.
     */
    static class SwapButtonListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) 
        {
            String text = swapBtn.getText();
            if(text.equals("Default"))
            {
                swapBtn.setText("JSON Packer");
                pichu.active = false;
                pichu.visible = false;

                alolan_raichu.active = true;
                alolan_raichu.visible = true;
            }
            else if(text.equals("JSON Packer"))
            {
                swapBtn.setText("Sparrow");
                alolan_raichu.active = false;
                alolan_raichu.visible = false;

                vaporeon.active = true;
                vaporeon.visible = true;
            }
            else
            {
                swapBtn.setText("Default");
                vaporeon.active = false;
                vaporeon.visible = false;

                pichu.active = true;
                pichu.visible = true;
            }
        }
    }

    static class ShowBoundsButtonListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) 
        {
            pichu.showBounds = !pichu.showBounds;            
            alolan_raichu.showBounds = !alolan_raichu.showBounds;
            vaporeon.showBounds = !vaporeon.showBounds;
        }
    }
}