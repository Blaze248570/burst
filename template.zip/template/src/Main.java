import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.burst.JBurst;
import javax.swing.burst.JBurstSprite;
import javax.swing.burst.graphics.JBurstGraphic;
import javax.swing.burst.graphics.frames.JBurstAtlasFrames;

public class Main 
{
    private static final int WINDOW_WIDTH = 1280, WINDOW_HEIGHT = 720;
    private static JBurst window;

    private static final int OBJ_WIDTH = 125, OBJ_HEIGHT = 30;
    private static JComboBox<String> dropDown;
    private static JCheckBox showBoundsBox;

    private static JBurstSprite pichu, raichu, vaporeon;

    public static void main(String[] args) 
    {
        // Create a JBurst object with the dimensions 800 x 700 pixels.
        window = new JBurst(WINDOW_WIDTH, WINDOW_HEIGHT);


        /*
         * This creates a red square with an "open-window" that the pokemon will reside within.
         */
        JBurstSprite greySQ = new JBurstSprite(0, 0).makeGraphic(WINDOW_WIDTH / 2, WINDOW_HEIGHT, new Color(230, 86, 98));
        Rectangle whiteSQ = new Rectangle();
        whiteSQ.setLocation((int)(greySQ.getWidth() * 0.125), 50);
        whiteSQ.width = whiteSQ.height = (int)(greySQ.getWidth() * 0.75);
        
        /*
         * By getting the sprite's pixel data, we're able to edit it's graphical data.
         */
        Graphics2D sqPixels = greySQ.getPixels();
        sqPixels.setColor(new Color(238, 238, 238));
        sqPixels.fillRoundRect(
            whiteSQ.x,
            whiteSQ.y,
            whiteSQ.width,
            whiteSQ.height,
            25, 
            25
        );


        /*
         * This creates a dropdown selector that will allow the user to select which pokemon to display. 
         */
        dropDown = new JComboBox<>(new String[] {"Pichu", "Raichu", "Vaporeon"});
        dropDown.setSize(85, OBJ_HEIGHT);
        dropDown.setLocation(whiteSQ.x + 5, whiteSQ.y + whiteSQ.height + 15);
        dropDown.addActionListener(new DropDownListener());

        JLabel dropDownLabel = new JLabel("Pokemon");
        dropDownLabel.setSize(OBJ_WIDTH, OBJ_HEIGHT);
        dropDownLabel.setLocation(dropDown.getX() + dropDown.getWidth() + 5, dropDown.getY());

        JBurstSprite dropDownBox = new JBurstSprite(dropDownLabel.getX() - 5, dropDownLabel.getY()).makeGraphic(70, OBJ_HEIGHT, new Color(238, 238, 238));
        Graphics2D ddbPixels = dropDownBox.getPixels();
        ddbPixels.setColor(new Color(122, 138, 153));
        ddbPixels.drawRect(0, 0, dropDownBox.getWidth() - 1, dropDownBox.getHeight() - 1);

        /*
         * This creates a checkbox that we'll use to toggle whether the sprite boundaries should
         * be displayed or not. 
         */
        showBoundsBox = new JCheckBox("Toggle bounds");
        showBoundsBox.setBounds(dropDown.getX(), dropDown.getY() + OBJ_HEIGHT + 10, OBJ_WIDTH, OBJ_HEIGHT);
        showBoundsBox.addActionListener(new ShowBoundsBoxListener());


        /*
         * The first sprite uses a spritesheet formatted with the same dimensions for each frame,
         * Allowing for it to be cut evenly without complication.
         * Animations are seperated by indices, starting at zero. 
         * So one animation may be {0, 1, 2, 3} and another may be {10, 11, 12, 13}
         */
        pichu = new JBurstSprite();
        pichu.loadAnimatedGraphic(JBurstGraphic.fromFile("assets/pichu_sheet.png", "pichu"), 175, 175);
        int[] frames = new int[44];
        for(int i = 0; i < 44; i++) frames[i] = i;
        pichu.animation.add("Dance", frames);
        pichu.animation.play("Dance");
        
        int pichuX = greySQ.getX() + (greySQ.getWidth() / 2) - (pichu.getWidth() / 2);
        int pichuY = (WINDOW_HEIGHT / 2) - (pichu.getHeight() / 2);
        pichu.setLocation(pichuX, pichuY);
        pichu.animation.callback = (String name, Integer frameNumber, Integer frameIndex) -> { };


        /*
         * The second sprite also uses a spritesheet, but the frames are not all the same size.
         * A JSON file is included alongside it with the instructions on how to cut it apart.
         * Adding animations is much simpler this way as each one is assigned a label. 
         * Simply name it, provide its label on the instruction file, and you're good to go.
         */
        raichu = new JBurstSprite(50, 20);        
        raichu.loadFrames(JBurstAtlasFrames.fromTexturePackerJson("assets/Alolan_Raichu.png", "assets/Alolan_Raichu.json"));
        raichu.animation.addByPrefix("dance", "Raichu Idle Dance", 24);
        raichu.animation.play("dance", true, false, 0);
        raichu.setScale(0.75f);
        raichu.kill();

        int raichuX = greySQ.getX() + (greySQ.getWidth() / 2) - (raichu.getWidth() / 2);
        int raichuY = (WINDOW_HEIGHT / 2) - (raichu.getHeight() / 2) - 100;
        raichu.setLocation(raichuX, raichuY);


        /*
         * The final sprite has the same situation as the second, however it instead uses the sparrow packing method.
         * So, an XML file is provided alongside it instead.
         */
        vaporeon = new JBurstSprite(40, 60);
        vaporeon.loadFrames(JBurstAtlasFrames.fromSparrow("assets/Vaporeon.png", "assets/Vaporeon.xml"));
        vaporeon.animation.addByPrefix("dance", "Vaporeon Idle Dance", 24);
        vaporeon.animation.play("dance");
        vaporeon.setScale(0.75f);
        vaporeon.kill();

        int vaporeonX = greySQ.getX() + (greySQ.getWidth() / 2) - (vaporeon.getWidth() / 2);
        int vaporeonY = (WINDOW_HEIGHT / 2) - (vaporeon.getHeight() / 2) - 50;
        vaporeon.setLocation(vaporeonX, vaporeonY);


        /*
         * The objects are then added to the JBurst so that it knows to render them.
         * Object heirarchy in Java Swing goes by descending order.
         * In other words, the first object added will always be on top.
         */
        window.add(showBoundsBox);
        window.add(dropDown);
        window.add(dropDownLabel);
        window.add(dropDownBox);

        window.add(pichu);
        window.add(raichu);
        window.add(vaporeon);

        window.add(greySQ);

        // Makes the window visible (Makes it exist). Very important!
        window.setVisible(true);

        // Dumb, but necessary for now.
        while(true) 
        {
            window.update();
        }
    }

    /*
     * Listeners are common classes used to manage JComponents 
     * and instruct them what to do when they're interected with.
     */
    static class DropDownListener implements ActionListener
    {
        @Override
        @SuppressWarnings("rawtypes")
        public void actionPerformed(ActionEvent e)
        {
            JComboBox source = (JComboBox) e.getSource();
            String selected = (String) source.getSelectedItem();

            switch(selected)
            {
                case "Raichu":
                    pichu.kill();
                    raichu.revive();
                    vaporeon.kill();
                break;
                case "Vaporeon":
                    pichu.kill();
                    raichu.kill();
                    vaporeon.revive();
                break;
                default:
                    pichu.revive();
                    raichu.kill();
                    vaporeon.kill();
                break;
            }
        }
    }

    static class ShowBoundsBoxListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) 
        {
            pichu.showBounds = !pichu.showBounds;            
            raichu.showBounds = !raichu.showBounds;
            vaporeon.showBounds = !vaporeon.showBounds;
        }
    }
}