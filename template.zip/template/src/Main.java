import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

import burst.JBurstSprite;

public class Main
{
    static JFrame window;

    static Dimension size = new Dimension(1280, 720);

    public static void main(String[] args) 
    {
        window = new JFrame("Test Burst Application");
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Dimension resolution = Toolkit.getDefaultToolkit().getScreenSize();
        int windowX = (int) (resolution.getWidth() / 2 - size.width / 2);
        int windowY = (int) (resolution.getHeight() / 2 - size.height / 2);
        window.setLocation(windowX, windowY);
        window.setSize(size);
        window.setLayout(null);

        SwingUtilities.invokeLater(() -> create());
    }

    public static final int OBJ_WIDTH = 125, OBJ_HEIGHT = 30;
    public static JComboBox<String> dropDown;
    public static JCheckBox showBoundsBox, spinBox;

    public static PichuSprite pichu;
    public static RaichuSprite raichu;
    public static VaporeonSprite vaporeon;

    public static void create()
    {
        /*
         * This creates a red square with an "open window" that the pokemon will reside within.
         */
        JBurstSprite redSQ = new JBurstSprite().makeGraphic(size.width / 2, size.width, new Color(230, 86, 98));
        Rectangle whiteSQ = new Rectangle();
        whiteSQ.setLocation((int)(redSQ.getWidth() * 0.125), 50);
        whiteSQ.width = whiteSQ.height = (int)(redSQ.getWidth() * 0.75);

        /*
         * By getting the sprite's pixel data, we're able to edit it's graphical data.
         */
        Graphics2D sqPixels = redSQ.getPixels();
        sqPixels.setColor(new Color(238, 238, 238));
        sqPixels.fillRoundRect(
            whiteSQ.x,
            whiteSQ.y,
            whiteSQ.width,
            whiteSQ.height,
            25, 
            25
        );

        /*
         * This creates a dropdown selector that will allow the user to select which pokemon to display. 
         */
        dropDown = new JComboBox<>(new String[] {"Pichu", "Raichu", "Vaporeon"});
        dropDown.setSize(85, OBJ_HEIGHT);
        dropDown.setLocation(whiteSQ.x + 5, whiteSQ.y + whiteSQ.height + 15);
        dropDown.addActionListener(new DropDownListener());

        JLabel dropDownLabel = new JLabel("Pokemon");
        dropDownLabel.setSize(OBJ_WIDTH, OBJ_HEIGHT);
        dropDownLabel.setLocation(dropDown.getX() + dropDown.getWidth() + 5, dropDown.getY());

        JBurstSprite dropDownBox = new JBurstSprite(dropDownLabel.getX() - 5, dropDownLabel.getY()).makeGraphic(70, OBJ_HEIGHT, new Color(238, 238, 238));

        /*
         * This creates a checkbox that we'll use to toggle whether the sprite boundaries should
         * be displayed or not. 
         */
        showBoundsBox = new JCheckBox("Toggle Bounds");
        showBoundsBox.setBounds(dropDown.getX(), dropDown.getY() + OBJ_HEIGHT + 10, OBJ_WIDTH, OBJ_HEIGHT);
        showBoundsBox.addActionListener(new ShowBoundsBoxListener());

        spinBox = new JCheckBox("Spin Sprite");
        spinBox.setBounds(showBoundsBox.getX(), showBoundsBox.getY() + OBJ_HEIGHT + 10, OBJ_WIDTH, OBJ_HEIGHT);
        spinBox.addActionListener(new SpinBoxListener());

        /*************************************************************/

        pichu = new PichuSprite();
        int pichuX = redSQ.getX() + (redSQ.getWidth() / 2) - (pichu.getWidth() / 2);
        int pichuY = (size.height / 2) - (pichu.getHeight() / 2);
        pichu.setPosition(pichuX, pichuY); // Centers the Pichu in the white box, regardless of size.
        // pichu.animation.callback = (String name, Integer frameNumber, Integer frameIndex) -> {};

        raichu = new RaichuSprite();
        int raichuX = redSQ.getX() + (redSQ.getWidth() / 2) - (raichu.getWidth() / 2);
        int raichuY = (size.height / 2) - (raichu.getHeight() / 2) - 100;
        raichu.setPosition(raichuX, raichuY); // Centers the Raichu in the white box, regardless of size.

        vaporeon = new VaporeonSprite();
        int vaporeonX = redSQ.getX() + (redSQ.getWidth() / 2) - (vaporeon.getWidth() / 2);
        int vaporeonY = (size.height / 2) - (vaporeon.getHeight() / 2) - 50;
        vaporeon.setPosition(vaporeonX, vaporeonY); // Centers the Vaporeon in the white box, regardless of size.

        /*
            JLabel basic = new JLabel();

            basic.getInputMap().put(KeyStroke.getKeyStroke("S"), "pressed_S");
            Action action = new AbstractAction() {
                @Override
                public void actionPerformed(ActionEvent e) { }
            };
            
            basic.getActionMap().put("pressed_S", action);
            add(basic);
        */

        /*************************************************************/

        /*
         * The objects are then added to the JBurst so that it knows to render them.
         * Object heirarchy in Java Swing goes by descending order.
         * In other words, the first object added will always be on top.
         */

        Container pane = window.getContentPane();

        pane.add(showBoundsBox);
        pane.add(dropDown);
        pane.add(dropDownLabel);
        pane.add(dropDownBox);
        pane.add(spinBox);

        pane.add(pichu);
        pane.add(raichu);
        pane.add(vaporeon);
        pane.add(redSQ);

        /*
         * Any time a new component is added, the window must be revalidated
         * in order for it to acknowledge it.
         * It's not necessary here as setVisible() will revalidate the window,
         * but it's good practice to include at the end of functions that 
         * add or remove components.
         */
        window.revalidate();
        window.setVisible(true);
    }

    /*
     * Listeners are common classes used to manage JComponents 
     * and give them instructions when they're interected with.
     */
    static class DropDownListener implements ActionListener
    {
        @Override
        @SuppressWarnings("rawtypes")
        public void actionPerformed(ActionEvent e)
        {
            JComboBox source = (JComboBox) e.getSource();
            String selected = (String) source.getSelectedItem();

            switch(selected)
            {
                case "Raichu":
                    pichu.kill();
                    raichu.revive();
                    vaporeon.kill();
                break;
                case "Vaporeon":
                    pichu.kill();
                    raichu.kill();
                    vaporeon.revive();
                break;
                default:
                    pichu.revive();
                    raichu.kill();
                    vaporeon.kill();
                break;
            }
        }
    }

    static class ShowBoundsBoxListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) 
        {
            pichu.debugMode = !pichu.debugMode;            
            raichu.debugMode = !raichu.debugMode;
            vaporeon.debugMode = !vaporeon.debugMode;
        }
    }

    static class SpinBoxListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) 
        {
            pichu.spin = !pichu.spin;            
            raichu.spin = !raichu.spin;
            vaporeon.spin = !vaporeon.spin;
        }
    }
}