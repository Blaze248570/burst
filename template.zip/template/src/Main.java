import burst.JBurst;
import burst.JBurstSprite;
import burst.graphics.JBurstGraphic;
import burst.graphics.frames.JBurstAtlasFrames;
import javax.swing.JButton;

public class Main 
{
    static JButton swapButton;
    static JBurstSprite pichu, alolan_raichu, vaporeon;

    public static void main(String[] args) 
    {
        JBurst app = new JBurst(800, 700);

        swapButton = new JButton("Default");
        swapButton.setBounds(25, 25, 125, 30);
        swapButton.addActionListener(new SwapButtonListener());

        pichu = new JBurstSprite(150, 150);
        pichu.loadAnimatedGraphic(JBurstGraphic.fromFile("assets/pichu_sheet.png", "pichu"), 175, 175);
        int[] frames = new int[44];
        for(int i = 0; i < 44; i++) frames[i] = i;
        pichu.animation.add("Dance", frames, 30, true);
        pichu.animation.play("Dance");


        alolan_raichu = new JBurstSprite(50, 20);
        alolan_raichu.loadFrames(JBurstAtlasFrames.fromTexturePackerJson("assets/Alolan_Raichu.png", "assets/Alolan_Raichu.json"));
        alolan_raichu.animation.addByPrefix("dance", "Raichu Idle Dance", 24, true);
        alolan_raichu.animation.play("dance", true, false, 0);
        alolan_raichu.active = false;
        alolan_raichu.visible = false;
        

        vaporeon = new JBurstSprite(60, 50);
        vaporeon.loadFrames(JBurstAtlasFrames.fromSparrow("assets/Vaporeon.png", "assets/Vaporeon.xml"));
        vaporeon.animation.addByPrefix("dance", "Vaporeon Idle Dance", 24, true);
        vaporeon.animation.play("dance");
        vaporeon.active = false;
        vaporeon.visible = false;

        app.add(swapButton);
        app.add(pichu);
        app.add(alolan_raichu);
        app.add(vaporeon);

        // Important!
        app.setVisible(true);

        while(true) 
        {
            app.update();
        }
    }

    static class SwapButtonListener implements java.awt.event.ActionListener
    {
        @Override
        public void actionPerformed(java.awt.event.ActionEvent e) 
        {
            String text = swapButton.getText();
            if(text.equals("Default"))
            {
                swapButton.setText("JSON Packer");
                pichu.active = false;
                pichu.visible = false;

                alolan_raichu.active = true;
                alolan_raichu.visible = true;
            }
            else if(text.equals("JSON Packer"))
            {
                swapButton.setText("Sparrow");
                alolan_raichu.active = false;
                alolan_raichu.visible = false;

                vaporeon.active = true;
                vaporeon.visible = true;
            }
            else
            {
                swapButton.setText("Default");
                vaporeon.active = false;
                vaporeon.visible = false;

                pichu.active = true;
                pichu.visible = true;
            }
        }
    }
}