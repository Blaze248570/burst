import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.burst.JBurst;
import javax.swing.burst.JBurstSprite;

public class Main
{
    public static final int WINDOW_WIDTH = 1280, WINDOW_HEIGHT = 720;
    public static JBurst window;

    public static final int OBJ_WIDTH = 125, OBJ_HEIGHT = 30;
    public static JComboBox<String> dropDown;
    public static JCheckBox showBoundsBox, spinBox;

    public static PichuSprite pichu;
    public static RaichuSprite raichu;
    public static VaporeonSprite vaporeon;

    public static void main(String[] args) 
    {
        // Create a JBurst object with the dimensions 800 x 700 pixels.
        window = new JBurst(WINDOW_WIDTH, WINDOW_HEIGHT);

        /*************************************************************/

        /*
         * This creates a red square with an "open-window" that the pokemon will reside within.
         */
        JBurstSprite redSQ = new JBurstSprite(0, 0).makeGraphic(WINDOW_WIDTH / 2, WINDOW_HEIGHT, new Color(230, 86, 98));
        Rectangle whiteSQ = new Rectangle();
        whiteSQ.setLocation((int)(redSQ.getWidth() * 0.125), 50);
        whiteSQ.width = whiteSQ.height = (int)(redSQ.getWidth() * 0.75);
        
        /*
         * By getting the sprite's pixel data, we're able to edit it's graphical data.
         */
        Graphics2D sqPixels = redSQ.getPixels();
        sqPixels.setColor(new Color(238, 238, 238));
        sqPixels.fillRoundRect(
            whiteSQ.x,
            whiteSQ.y,
            whiteSQ.width,
            whiteSQ.height,
            25, 
            25
        );

        /*
         * This creates a dropdown selector that will allow the user to select which pokemon to display. 
         */
        dropDown = new JComboBox<>(new String[] {"Pichu", "Raichu", "Vaporeon"});
        dropDown.setSize(85, OBJ_HEIGHT);
        dropDown.setLocation(whiteSQ.x + 5, whiteSQ.y + whiteSQ.height + 15);
        dropDown.addActionListener(new DropDownListener());

        JLabel dropDownLabel = new JLabel("Pokemon");
        dropDownLabel.setSize(OBJ_WIDTH, OBJ_HEIGHT);
        dropDownLabel.setLocation(dropDown.getX() + dropDown.getWidth() + 5, dropDown.getY());

        JBurstSprite dropDownBox = new JBurstSprite(dropDownLabel.getX() - 5, dropDownLabel.getY()).makeGraphic(70, OBJ_HEIGHT, new Color(238, 238, 238));
        Graphics2D ddbPixels = dropDownBox.getPixels();
        ddbPixels.setColor(new Color(122, 138, 153));
        ddbPixels.drawRect(0, 0, dropDownBox.getWidth() - 1, dropDownBox.getHeight() - 1);
        ddbPixels.dispose();

        /*
         * This creates a checkbox that we'll use to toggle whether the sprite boundaries should
         * be displayed or not. 
         */
        showBoundsBox = new JCheckBox("Toggle Bounds");
        showBoundsBox.setBounds(dropDown.getX(), dropDown.getY() + OBJ_HEIGHT + 10, OBJ_WIDTH, OBJ_HEIGHT);
        showBoundsBox.addActionListener(new ShowBoundsBoxListener());

        spinBox = new JCheckBox("Spin Sprite");
        spinBox.setBounds(showBoundsBox.getX(), showBoundsBox.getY() + OBJ_HEIGHT + 10, OBJ_WIDTH, OBJ_HEIGHT);
        spinBox.addActionListener(new SpinBoxListener());

        /*************************************************************/

        pichu = new PichuSprite();
        int pichuX = redSQ.getX() + (redSQ.getSpriteWidth() / 2) - (pichu.getSpriteWidth() / 2);
        int pichuY = (WINDOW_HEIGHT / 2) - (pichu.getSpriteHeight() / 2);
        pichu.setPosition(pichuX, pichuY); // Centers the Pichu in the white box, regardless of size.

        // pichu.animation.callback = (String name, Integer frameNumber, Integer frameIndex) -> {};


        raichu = new RaichuSprite();
        int raichuX = redSQ.getX() + (redSQ.getWidth() / 2) - (raichu.getWidth() / 2);
        int raichuY = (WINDOW_HEIGHT / 2) - (raichu.getHeight() / 2) - 100;
        raichu.setPosition(raichuX, raichuY); // Centers the Raichu in the white box, regardless of size.

        
        vaporeon = new VaporeonSprite();
        int vaporeonX = redSQ.getX() + (redSQ.getWidth() / 2) - (vaporeon.getWidth() / 2);
        int vaporeonY = (WINDOW_HEIGHT / 2) - (vaporeon.getHeight() / 2) - 50;
        vaporeon.setPosition(vaporeonX, vaporeonY); // Centers the Vaporeon in the white box, regardless of size.

        /*************************************************************/

        /*
         * The objects are then added to the JBurst so that it knows to render them.
         * Object heirarchy in Java Swing goes by descending order.
         * In other words, the first object added will always be on top.
         */
        window.add(showBoundsBox);
        window.add(dropDown);
        window.add(dropDownLabel);
        window.add(dropDownBox);
        window.add(spinBox);

        window.add(pichu);
        window.add(raichu);
        window.add(vaporeon);

        window.add(redSQ);

        // Makes the window visible (and exist). Very important!
        window.setVisible(true);

        // Dumb, but necessary for now.
        while(true) 
        {
            window.update();
        }
    }

    /*
     * Listeners are common classes used to manage JComponents 
     * and give them instructions when they're interected with.
     */
    static class DropDownListener implements ActionListener
    {
        @Override
        @SuppressWarnings("rawtypes")
        public void actionPerformed(ActionEvent e)
        {
            JComboBox source = (JComboBox) e.getSource();
            String selected = (String) source.getSelectedItem();

            switch(selected)
            {
                case "Raichu":
                    pichu.kill();
                    raichu.revive();
                    vaporeon.kill();
                break;
                case "Vaporeon":
                    pichu.kill();
                    raichu.kill();
                    vaporeon.revive();
                break;
                default:
                    pichu.revive();
                    raichu.kill();
                    vaporeon.kill();
                break;
            }
        }
    }

    static class ShowBoundsBoxListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) 
        {
            pichu.debugMode = !pichu.debugMode;            
            raichu.debugMode = !raichu.debugMode;
            vaporeon.debugMode = !vaporeon.debugMode;
        }
    }

    static class SpinBoxListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) 
        {
            pichu.spin = !pichu.spin;            
            raichu.spin = !raichu.spin;
            vaporeon.spin = !vaporeon.spin;
        }
    }
}