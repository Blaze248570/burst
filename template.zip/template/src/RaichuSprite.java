import javax.swing.burst.JBurstSprite;
import javax.swing.burst.graphics.frames.JBurstAtlasFrames;

/**
 * An extended class of JBurstSprite used to draw a Raichu.
 * <p>
 * This class employs the {@code fromTexturePackerJson()} method to parse its spritesheet.
 */
public class RaichuSprite extends JBurstSprite
{
    public final String file_location = "assets/Alolan_Raichu";

    public boolean spin = false;

    public RaichuSprite()
    {
        super();

        loadFrames(JBurstAtlasFrames.fromTexturePackerJson(file_location + ".png", file_location + ".json"));

        animation.addByPrefix("dance", "Raichu Idle Dance", 24);
        animation.play("dance", true, false, 0);

        setScale(0.75);
        kill();
    }

    @Override
    public void update(double elapsed)
    {
        super.update(elapsed);

        if(spin)
            setAngle(getAngle() + Math.toRadians(elapsed / 2));
        else
            setAngle(0.0);
    }
}
