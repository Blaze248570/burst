import javax.swing.burst.JBurstSprite;
import javax.swing.burst.graphics.frames.JBurstAtlasFrames;

/**
 * An extended class of JBurstSprite used to draw a Vaporeon.
 * <p>
 * This class employs the {@code fromSparrow()} method to parse its spritesheet.
 */
public class VaporeonSprite extends JBurstSprite
{
    public final String file_location = "assets/Vaporeon";

    public boolean spin = false;

    public VaporeonSprite()
    {
        super();

        loadFrames(JBurstAtlasFrames.fromSparrow(file_location + ".png", file_location + ".xml"));

        animation.addByPrefix("dance", "Vaporeon Idle Dance", 24);
        animation.play("dance");

        setScale(0.75);
        kill();
    }

    @Override
    public void update(double elapsed)
    {
        super.update(elapsed);

        if(spin)
            setAngle(getAngle() + Math.toRadians(elapsed / 2));
        else
            setAngle(0.0);
    }
}
